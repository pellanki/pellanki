package com.app.countryapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.app.countryapp.databinding.ItemCountryDetailsBinding
import com.app.countryapp.model.CountryItem


class CountryListAdapter: RecyclerView.Adapter<CountryListAdapter.CountryViewHolder>(){

    var countryList = listOf<CountryItem>()
    inner class CountryViewHolder(val binding: ItemCountryDetailsBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =  CountryViewHolder(
        ItemCountryDetailsBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
    )

    override fun getItemCount() = countryList.size

    override fun onBindViewHolder(holder: CountryViewHolder, position: Int) {
        holder.binding.let {
            it.nameTv.text = "${countryList[position].name}, ${countryList[position].region}"
            it.capitalTv.text = countryList[position].capital
            it.codeTv.text = countryList[position].code
        }
    }

}