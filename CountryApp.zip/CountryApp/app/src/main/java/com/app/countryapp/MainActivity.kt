package com.app.countryapp

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.countryapp.databinding.ActivityMainBinding
import com.app.countryapp.network.RetrofitInstance
import com.app.countryapp.repository.CountryRepositoryImpl
import com.app.countryapp.viewmodels.MainViewModel
import com.app.countryapp.viewmodels.MainViewModelImpl

class MainActivity : AppCompatActivity() {
    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById(R.id.toolbar))
        setTitle(getString(R.string.app_name))
        val countryListRv = findViewById<RecyclerView>(R.id.country_list)
        val errorTv = findViewById<TextView>(R.id.error_tv)
        val repository = CountryRepositoryImpl(RetrofitInstance.apiService)
        val factory = MainViewModelImpl.Factory(repository)
        viewModel = factory.create(MainViewModelImpl::class.java)
        val adapter = CountryListAdapter()
        countryListRv.adapter = adapter
        viewModel.errorLiveData.observe(this) {
            countryListRv.visibility = View.GONE
            errorTv.visibility = View.VISIBLE
            errorTv.text = getString(R.string.unable_to_load_data)
        }
        viewModel.countryListLiveData.observe(this) {
            if (it.isEmpty()) {
                countryListRv.visibility = View.GONE
                errorTv.visibility = View.VISIBLE
                errorTv.text = getString(R.string.no_data_available)
            } else {
                countryListRv.visibility = View.VISIBLE
                errorTv.visibility = View.GONE
                adapter.countryList = it
                adapter.notifyDataSetChanged()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.getCountries()
    }
}