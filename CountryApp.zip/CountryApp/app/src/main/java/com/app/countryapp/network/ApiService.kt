package com.app.countryapp.network

import com.app.countryapp.model.CountryResponseItem
import retrofit2.Response
import retrofit2.http.GET

interface ApiService {

    @GET("countries.json")
    suspend fun getCountries(): Response<List<CountryResponseItem>?>
}