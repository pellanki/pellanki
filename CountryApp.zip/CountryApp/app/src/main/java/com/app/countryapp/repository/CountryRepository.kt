package com.app.countryapp.repository

import com.app.countryapp.model.CountryItem

abstract class CountryRepository {

    abstract suspend fun getCountries(): List<CountryItem>
}