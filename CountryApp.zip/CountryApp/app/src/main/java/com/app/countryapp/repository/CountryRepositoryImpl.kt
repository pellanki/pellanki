package com.app.countryapp.repository

import com.app.countryapp.model.CountryItem
import com.app.countryapp.network.ApiService

class CountryRepositoryImpl(private val apiService: ApiService): CountryRepository() {

    override suspend fun getCountries(): List<CountryItem> {
        val countryList = arrayListOf<CountryItem>()
       val response = apiService.getCountries()
        if (response.isSuccessful) {
            response.body()?.let {
                it.forEach { item ->
                    countryList.add(
                        CountryItem(item.name, item.region, item.code, item.capital)
                    )
                }
            }
        }
        return countryList
    }
}