package com.app.countryapp.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.app.countryapp.model.CountryItem

abstract class MainViewModel: ViewModel() {

    abstract val countryListLiveData: LiveData<List<CountryItem>>
    abstract val errorLiveData: LiveData<String>
    abstract fun getCountries()
}