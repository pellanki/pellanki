package com.app.countryapp.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.app.countryapp.model.CountryItem
import com.app.countryapp.repository.CountryRepository
import kotlinx.coroutines.launch

class MainViewModelImpl(private val repository: CountryRepository): MainViewModel() {

    override val countryListLiveData = MutableLiveData<List<CountryItem>>()
    override val errorLiveData = MutableLiveData<String>()

    override fun getCountries() {
        viewModelScope.launch {
            try {
                countryListLiveData.value = repository.getCountries()
            } catch (exp: Exception) {
                errorLiveData.value = exp.message
            }
        }
    }

    class Factory(private val repository: CountryRepository): ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModelImpl(repository) as T
        }
    }
}